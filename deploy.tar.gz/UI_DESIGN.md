# MonkeySurvey - Mobile UI Design

## Design System

### Color Palette

#### Primary Colors
- **Primary**: `#6366F1` (Indigo) - Main brand color
- **Primary Dark**: `#4F46E5` - Hover states, active buttons
- **Primary Light**: `#A5B4FC` - Backgrounds, subtle highlights

#### Secondary Colors
- **Secondary**: `#10B981` (Emerald) - Success states, completed surveys
- **Accent**: `#F59E0B` (Amber) - Warnings, important notices
- **Error**: `#EF4444` (Red) - Error states, destructive actions

#### Neutral Colors
- **Background**: `#F9FAFB` (Light gray)
- **Surface**: `#FFFFFF` (White)
- **Border**: `#E5E7EB` (Light gray)
- **Text Primary**: `#111827` (Dark gray)
- **Text Secondary**: `#6B7280` (Medium gray)

### Typography

#### Font Family
- **Primary**: Inter, SF Pro, Roboto
- **Monospace**: JetBrains Mono (for codes/IDs)

#### Font Sizes
- **H1**: 32px / 2rem - Page titles
- **H2**: 24px / 1.5rem - Section headers
- **H3**: 20px / 1.25rem - Card titles
- **Body**: 16px / 1rem - Main content
- **Small**: 14px / 0.875rem - Labels, captions
- **Tiny**: 12px / 0.75rem - Helper text

#### Font Weights
- **Bold**: 700 - Headlines
- **Semibold**: 600 - Subheadings
- **Medium**: 500 - Buttons, labels
- **Regular**: 400 - Body text

### Spacing
- **xs**: 4px
- **sm**: 8px
- **md**: 16px
- **lg**: 24px
- **xl**: 32px
- **2xl**: 48px

### Border Radius
- **sm**: 4px - Input fields
- **md**: 8px - Buttons, cards
- **lg**: 16px - Modals, large containers
- **full**: 9999px - Pills, avatars

### Shadows
- **sm**: `0 1px 2px rgba(0, 0, 0, 0.05)`
- **md**: `0 4px 6px rgba(0, 0, 0, 0.1)`
- **lg**: `0 10px 15px rgba(0, 0, 0, 0.1)`
- **xl**: `0 20px 25px rgba(0, 0, 0, 0.15)`

## Screen Designs

### 1. Authentication Screens

#### Login Screen
```
┌─────────────────────────┐
│   [MonkeySurvey Logo]   │
│                         │
│   Welcome Back          │
│   Sign in to continue   │
│                         │
│   ┌─────────────────┐   │
│   │ Email           │   │
│   └─────────────────┘   │
│                         │
│   ┌─────────────────┐   │
│   │ Password        │   │
│   └─────────────────┘   │
│                         │
│   [ Forgot Password? ]  │
│                         │
│   ┌───────────────────┐ │
│   │   SIGN IN         │ │
│   └───────────────────┘ │
│                         │
│   Don't have account?   │
│   [ Sign Up ]           │
│                         │
│   ─────── OR ───────    │
│                         │
│   [ Continue with      │
│     Google  ]          │
│                         │
└─────────────────────────┘
```

#### Registration Screen
```
┌─────────────────────────┐
│   [← Back]              │
│                         │
│   Create Account        │
│   Start your survey     │
│   journey               │
│                         │
│   ┌─────────────────┐   │
│   │ First Name      │   │
│   └─────────────────┘   │
│                         │
│   ┌─────────────────┐   │
│   │ Last Name       │   │
│   └─────────────────┘   │
│                         │
│   ┌─────────────────┐   │
│   │ Email           │   │
│   └─────────────────┘   │
│                         │
│   ┌─────────────────┐   │
│   │ Password        │   │
│   └─────────────────┘   │
│                         │
│   ☐ I agree to Terms   │
│                         │
│   ┌───────────────────┐ │
│   │   CREATE ACCOUNT  │ │
│   └───────────────────┘ │
│                         │
└─────────────────────────┘
```

### 2. Dashboard/Home Screen

```
┌─────────────────────────────────┐
│ ☰  MonkeySurvey    🔔  👤       │
├─────────────────────────────────┤
│ Hello, John! 👋                 │
│ 5 active surveys                │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ 📊 Quick Stats              │ │
│ │ ┌──────┐ ┌──────┐ ┌──────┐ │ │
│ │ │ 1234 │ │  45  │ │ 87%  │ │ │
│ │ │Respns│ │Survys│ │Compl │ │ │
│ │ └──────┘ └──────┘ └──────┘ │ │
│ └─────────────────────────────┘ │
│                                 │
│ My Surveys         [ + New ]    │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ 📝 Customer Satisfaction    │ │
│ │    Survey                   │ │
│ │    ━━━━━━━━━━━━ 87%        │ │
│ │    45 responses • Active    │ │
│ │    [ View ] [ Edit ]        │ │
│ └─────────────────────────────┘ │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ 📊 Product Feedback         │ │
│ │    ━━━━━━━━━━━━ 62%        │ │
│ │    23 responses • Active    │ │
│ │    [ View ] [ Edit ]        │ │
│ └─────────────────────────────┘ │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ 📋 Employee Engagement      │ │
│ │    ━━━━━━━━━━━━ 45%        │ │
│ │    12 responses • Draft     │ │
│ │    [ View ] [ Edit ]        │ │
│ └─────────────────────────────┘ │
│                                 │
└─────────────────────────────────┘
│ [🏠] [📊] [➕] [📈] [👤]       │
└─────────────────────────────────┘
```

### 3. Create Survey Screen

```
┌─────────────────────────────────┐
│ [← Back]  New Survey      [💾] │
├─────────────────────────────────┤
│                                 │
│ Survey Details                  │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ Survey Title                │ │
│ │ Customer Satisfaction...    │ │
│ └─────────────────────────────┘ │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ Description (optional)      │ │
│ │ Help us improve...          │ │
│ │                             │ │
│ └─────────────────────────────┘ │
│                                 │
│ Category                        │
│ ┌─────────────────────────────┐ │
│ │ Customer Feedback     ▼     │ │
│ └─────────────────────────────┘ │
│                                 │
│ Questions                       │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ ⋮ Q1: Rating Scale          │ │
│ │   How satisfied are you...  │ │
│ │   [ Edit ] [ Delete ]       │ │
│ └─────────────────────────────┘ │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ ⋮ Q2: Multiple Choice       │ │
│ │   Which features do you...  │ │
│ │   [ Edit ] [ Delete ]       │ │
│ └─────────────────────────────┘ │
│                                 │
│ ┌───────────────────────────┐   │
│ │ + Add Question            │   │
│ └───────────────────────────┘   │
│                                 │
│ Settings                        │
│ ☑ Require login                │
│ ☐ Allow multiple submissions   │
│ ☑ Show results to respondents  │
│                                 │
│ ┌─────────────────────────────┐ │
│ │   SAVE AS DRAFT             │ │
│ └─────────────────────────────┘ │
│ ┌─────────────────────────────┐ │
│ │   PUBLISH SURVEY            │ │
│ └─────────────────────────────┘ │
│                                 │
└─────────────────────────────────┘
```

### 4. Question Builder Screen

```
┌─────────────────────────────────┐
│ [← Back]  Add Question    [✓]  │
├─────────────────────────────────┤
│                                 │
│ Question Type                   │
│ ┌─────────────────────────────┐ │
│ │ Rating Scale          ▼     │ │
│ └─────────────────────────────┘ │
│                                 │
│ [📝][☑][⭘][⭐][📅][📊][⋮]    │
│                                 │
│ Question Text                   │
│ ┌─────────────────────────────┐ │
│ │ How satisfied are you with  │ │
│ │ our service?                │ │
│ └─────────────────────────────┘ │
│                                 │
│ Description (optional)          │
│ ┌─────────────────────────────┐ │
│ │ Rate from 1-5 stars         │ │
│ └─────────────────────────────┘ │
│                                 │
│ Rating Settings                 │
│ Scale: ⭐⭐⭐⭐⭐ (1-5)          │
│                                 │
│ Labels (optional)               │
│ ┌──────────┐     ┌──────────┐  │
│ │ Poor     │  ━  │ Excellent│  │
│ └──────────┘     └──────────┘  │
│                                 │
│ ☑ Required question             │
│ ☐ Add skip logic                │
│                                 │
│ ┌─────────────────────────────┐ │
│ │   ADD QUESTION              │ │
│ └─────────────────────────────┘ │
│                                 │
└─────────────────────────────────┘
```

### 5. Take Survey Screen (Respondent View)

```
┌─────────────────────────────────┐
│ Customer Satisfaction Survey    │
│ Progress: ━━━━━━━░░░░ 60%      │
├─────────────────────────────────┤
│                                 │
│ Question 3 of 5                 │
│                                 │
│ How satisfied are you with our  │
│ service?                        │
│                                 │
│ Rate from 1-5 stars             │
│                                 │
│        ⭐ ⭐ ⭐ ⭐ ⭐           │
│        1  2  3  4  5            │
│                                 │
│   Poor              Excellent   │
│                                 │
│                                 │
│                                 │
│ ┌───────────────┐ ┌───────────┐ │
│ │   ← BACK      │ │  NEXT →   │ │
│ └───────────────┘ └───────────┘ │
│                                 │
│ [ Save & Continue Later ]       │
│                                 │
└─────────────────────────────────┘
```

### 6. Analytics/Reports Dashboard

```
┌─────────────────────────────────┐
│ [← Back]  Analytics       [📤]  │
├─────────────────────────────────┤
│ Customer Satisfaction Survey    │
│                                 │
│ Overview                        │
│ ┌──────┐ ┌──────┐ ┌──────┐     │
│ │  45  │ │ 87%  │ │ 3m   │     │
│ │Respns│ │Compl │ │AvgTm │     │
│ └──────┘ └──────┘ └──────┘     │
│                                 │
│ Response Rate                   │
│ ┌─────────────────────────────┐ │
│ │     ╱╲                      │ │
│ │    ╱  ╲      ╱╲             │ │
│ │   ╱    ╲    ╱  ╲            │ │
│ │  ╱      ╲  ╱    ╲           │ │
│ │ ────────────────────         │ │
│ │ Mon Tue Wed Thu Fri          │ │
│ └─────────────────────────────┘ │
│                                 │
│ Question Analysis               │
│                                 │
│ Q1: Service Satisfaction        │
│ ┌─────────────────────────────┐ │
│ │ ⭐⭐⭐⭐⭐ 5 stars ████ 48%  │ │
│ │ ⭐⭐⭐⭐   4 stars ███  33%  │ │
│ │ ⭐⭐⭐     3 stars █    11%  │ │
│ │ ⭐⭐       2 stars      4%   │ │
│ │ ⭐         1 star       2%   │ │
│ │                             │ │
│ │ Average: 4.2 ⭐             │ │
│ └─────────────────────────────┘ │
│                                 │
│ ┌─────────────────────────────┐ │
│ │   CREATE CUSTOM REPORT      │ │
│ └─────────────────────────────┘ │
│ ┌─────────────────────────────┐ │
│ │   EXPORT DATA (CSV/PDF)     │ │
│ └─────────────────────────────┘ │
│                                 │
└─────────────────────────────────┘
```

### 7. Custom Report Query Builder

```
┌─────────────────────────────────┐
│ [← Back]  Custom Report         │
├─────────────────────────────────┤
│ Report Name                     │
│ ┌─────────────────────────────┐ │
│ │ High Satisfaction Customers │ │
│ └─────────────────────────────┘ │
│                                 │
│ Filters                         │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ Question: Service Rating    │ │
│ │ Condition: Greater than     │ │
│ │ Value: 4                    │ │
│ │           [ Remove ]        │ │
│ └─────────────────────────────┘ │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ Date Range                  │ │
│ │ From: 2024-01-01            │ │
│ │ To:   2024-01-31            │ │
│ │           [ Remove ]        │ │
│ └─────────────────────────────┘ │
│                                 │
│ [ + Add Filter ]                │
│                                 │
│ Fields to Include               │
│ ☑ Respondent ID                 │
│ ☑ Completion Date               │
│ ☑ Location                      │
│ ☑ All Answers                   │
│ ☐ Device Type                   │
│ ☐ IP Address                    │
│                                 │
│ Group By                        │
│ ┌─────────────────────────────┐ │
│ │ Country              ▼      │ │
│ └─────────────────────────────┘ │
│                                 │
│ ┌─────────────────────────────┐ │
│ │   GENERATE REPORT           │ │
│ └─────────────────────────────┘ │
│ ┌─────────────────────────────┐ │
│ │   SAVE QUERY                │ │
│ └─────────────────────────────┘ │
│                                 │
└─────────────────────────────────┘
```

### 8. Profile/Settings Screen

```
┌─────────────────────────────────┐
│ [← Back]  Profile               │
├─────────────────────────────────┤
│        ┌──────────┐              │
│        │   👤     │              │
│        │  John D. │              │
│        └──────────┘              │
│                                 │
│ Account Information             │
│ ┌─────────────────────────────┐ │
│ │ 📧 john.doe@example.com     │ │
│ └─────────────────────────────┘ │
│ ┌─────────────────────────────┐ │
│ │ 👤 John Doe                 │ │
│ └─────────────────────────────┘ │
│                                 │
│ [ Edit Profile ]                │
│                                 │
│ Subscription                    │
│ ┌─────────────────────────────┐ │
│ │ 🎯 Pro Plan                 │ │
│ │ Unlimited surveys           │ │
│ │ Next billing: Jan 1, 2025   │ │
│ └─────────────────────────────┘ │
│                                 │
│ Settings                        │
│ ┌─────────────────────────────┐ │
│ │ 🔔 Notifications      [→]   │ │
│ └─────────────────────────────┘ │
│ ┌─────────────────────────────┐ │
│ │ 🌐 Language           [→]   │ │
│ └─────────────────────────────┘ │
│ ┌─────────────────────────────┐ │
│ │ 🔒 Privacy            [→]   │ │
│ └─────────────────────────────┘ │
│ ┌─────────────────────────────┐ │
│ │ ❓ Help & Support     [→]   │ │
│ └─────────────────────────────┘ │
│                                 │
│ [ Sign Out ]                    │
│                                 │
└─────────────────────────────────┘
```

## Component Library

### Buttons

#### Primary Button
- Background: Primary color (#6366F1)
- Text: White
- Height: 48px
- Border radius: 8px
- Font weight: 600

#### Secondary Button
- Background: Transparent
- Border: 2px solid Primary
- Text: Primary color
- Height: 48px
- Border radius: 8px

#### Text Button
- Background: Transparent
- Text: Primary color
- No border
- Underline on hover

### Input Fields

#### Text Input
- Height: 48px
- Border: 1px solid Border color
- Border radius: 8px
- Padding: 12px 16px
- Font size: 16px
- Focus: Primary color border

#### Textarea
- Min height: 120px
- Border: 1px solid Border color
- Border radius: 8px
- Padding: 12px 16px

#### Dropdown/Select
- Height: 48px
- Border: 1px solid Border color
- Border radius: 8px
- Chevron icon on right

### Cards

#### Survey Card
- Background: White
- Border: 1px solid Border color
- Border radius: 12px
- Padding: 16px
- Shadow: sm
- Hover: Shadow md

#### Stat Card
- Background: Gradient (Primary to Primary Light)
- Border radius: 12px
- Padding: 20px
- Text: White
- Large number display

### Navigation

#### Bottom Tab Bar
- Height: 64px
- Background: White
- Shadow: lg
- Icons: 24px
- Active color: Primary
- Inactive color: Text secondary

#### Top Navigation Bar
- Height: 56px
- Background: White
- Shadow: sm
- Title: H3
- Action icons: 24px

### Feedback

#### Toast Notification
- Border radius: 8px
- Shadow: lg
- Padding: 16px
- Auto-dismiss: 3 seconds
- Success: Green background
- Error: Red background
- Warning: Amber background

#### Progress Bar
- Height: 8px
- Background: Border color
- Fill: Primary color
- Border radius: full

#### Loading Spinner
- Size: 24px
- Color: Primary
- Center aligned

## Animations

### Page Transitions
- Duration: 300ms
- Easing: ease-in-out
- Type: Slide from right

### Button Press
- Scale: 0.95
- Duration: 100ms

### Card Hover
- Shadow: sm to md
- Duration: 200ms
- Transform: translateY(-2px)

### List Item Animations
- Stagger delay: 50ms
- Fade in + slide up
- Duration: 300ms

## Accessibility

### Text Contrast
- Minimum ratio: 4.5:1 for normal text
- Minimum ratio: 3:1 for large text

### Touch Targets
- Minimum size: 44x44px
- Spacing: 8px between targets

### Screen Reader Support
- All images have alt text
- Form fields have labels
- Buttons have descriptive text
- Navigation landmarks defined

### Keyboard Navigation
- Tab order follows visual flow
- Focus indicators visible
- All actions keyboard accessible
